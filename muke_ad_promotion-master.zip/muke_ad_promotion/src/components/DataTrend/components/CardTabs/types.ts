export interface CardItemType {
    name: string;
    value: string | number;
    persent: string | number;
    icon: string;
    isSelected: boolean;
    id: string;
}
