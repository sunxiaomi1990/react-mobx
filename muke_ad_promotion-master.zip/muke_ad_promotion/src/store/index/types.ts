export interface UserBalanceResType {
    data: any;
}
