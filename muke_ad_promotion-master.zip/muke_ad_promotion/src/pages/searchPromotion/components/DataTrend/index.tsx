import React, { Component } from 'react';
import './style.scss';

interface IProps { }

class DataTrend extends Component<IProps> {
    render() {
        return (
            <div className="account-component-box">
                DataTrend组件
            </div>
        );
    }
}

export default DataTrend;
