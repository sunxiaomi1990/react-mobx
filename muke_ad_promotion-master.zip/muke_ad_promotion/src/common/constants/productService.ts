const PRODUCTSERVICE_CONFIG = [
    {
        marketToolTitle: '课程通',
        marketToolImgUrl: 'https://iconfont.alicdn.com/t/1b139f4c-0478-4602-a906-9eb2a026f507.png',
        link: 'https://www.imooc.com/',
    },
    {
        marketToolTitle: '操作盘',
        marketToolImgUrl: 'https://iconfont.alicdn.com/t/eea86dbd-6780-4ec8-a0c1-9864968c9add.png',
        link: 'https://www.imooc.com/',
    },
    {
        marketToolTitle: '财务中心',
        marketToolImgUrl: 'https://iconfont.alicdn.com/t/bde5bbe9-7b3b-4593-b24b-ade45e0bcd53.png',
        link: 'https://www.imooc.com/',
    },
    {
        marketToolTitle: '创意中心',
        marketToolImgUrl: 'https://iconfont.alicdn.com/t/54673fd0-45be-4349-8c69-49d40eba2256.png',
        link: 'https://www.imooc.com/',
    },
    {
        marketToolTitle: '意见收集',
        marketToolImgUrl: 'https://iconfont.alicdn.com/t/5d6c4f11-7640-4415-a003-72d85784eea6.png',
        link: 'https://www.imooc.com/',
    },
    {
        marketToolTitle: '慕课搜索',
        marketToolImgUrl: 'https://iconfont.alicdn.com/t/c18643bc-1a1b-4b17-9b4f-1c6fc66dbf2d.png',
        link: '',
    },
    {
        marketToolTitle: '大事记',
        marketToolImgUrl: 'https://iconfont.alicdn.com/t/430a38af-790b-4a85-a798-e25cdaff2cb4.png',
        link: 'https://www.imooc.com/',
    },
    {
        marketToolTitle: '营销通',
        marketToolImgUrl: 'https://iconfont.alicdn.com/t/f3c149bc-6fb7-4c3b-8a26-b4976cddaa2f.png',
        link: 'https://www.imooc.com/',
    },
];

export default PRODUCTSERVICE_CONFIG;
