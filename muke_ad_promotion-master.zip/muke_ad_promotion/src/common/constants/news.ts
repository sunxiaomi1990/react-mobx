export const newsData1 = [
    {
        title: '审核问题支持线上反馈功能--全流量上线',
        source: '信息流推广',
        time: '2020-12-31',
        link: '',
    },
    {
        title: '审核问题支持线上反馈功能--全流量上线',
        source: '信息流推广',
        time: '2020-12-31',
        link: '',
    },
    {
        title: '审核问题支持线上反馈功能--全流量上线',
        source: '信息流推广',
        time: '2020-12-31',
        link: '',
    },
    {
        title: '审核问题支持线上反馈功能--全流量上线',
        source: '信息流推广',
        time: '2020-12-31',
        link: '',
    },
];

export const newsData2 = [
    {
        title: '生意罗盘、业务竞争分析工具下线',
        source: '搜索推广',
        time: '2020-12-30',
        link: '',
    },
    {
        title: '生意罗盘、业务竞争分析工具下线',
        source: '搜索推广',
        time: '2020-12-30',
        link: '',
    },
    {
        title: '生意罗盘、业务竞争分析工具下线',
        source: '搜索推广',
        time: '2020-12-30',
        link: '',
    },
    {
        title: '生意罗盘、业务竞争分析工具下线',
        source: '搜索推广',
        time: '2020-12-30',
        link: '',
    },
];

export const newsData3 = [
    {
        title: '数据报告相关功能升级&历史逻辑下线',
        source: '慕课营销API',
        time: '2020-12-30',
        link: '',
    },
    {
        title: '数据报告相关功能升级&历史逻辑下线',
        source: '慕课营销API',
        time: '2020-12-30',
        link: '',
    },
    {
        title: '数据报告相关功能升级&历史逻辑下线',
        source: '慕课营销API',
        time: '2020-12-30',
        link: '',
    },
    {
        title: '数据报告相关功能升级&历史逻辑下线',
        source: '慕课营销API',
        time: '2020-12-30',
        link: '',
    },
];

export const newsData4 = [
    {
        title: '搜索推广“应用推广”单元绑定渠道包升级--全流量上线',
        source: '慕课营销客户端',
        time: '2020-12-29',
        link: '',
    },
    {
        title: '搜索推广“应用推广”单元绑定渠道包升级--全流量上线',
        source: '慕课营销客户端',
        time: '2020-12-29',
        link: '',
    },
    {
        title: '搜索推广“应用推广”单元绑定渠道包升级--全流量上线',
        source: '慕课营销客户端',
        time: '2020-12-29',
        link: '',
    },
    {
        title: '搜索推广“应用推广”单元绑定渠道包升级--全流量上线',
        source: '慕课营销客户端',
        time: '2020-12-29',
        link: '',
    },
];
